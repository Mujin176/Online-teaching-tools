# coding: utf-8
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bootstrap import Bootstrap5
from flask_babelex import Babel
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_mail import Mail
from flask_ckeditor import CKEditor
import os
import logging
from config import config_by_name

db = SQLAlchemy()
flask_bcrypt = Bcrypt()

app = Flask(__name__)
app.config.from_object(config_by_name[os.getenv('FLASK_ENV') or config_by_name['default']])
db.init_app(app)
flask_bcrypt.init_app(app)
bootstrap = Bootstrap5(app)
babel = Babel(app)
login = LoginManager(app)
login.login_view = 'user_login'
mail = Mail(app)
CKEditor(app)

csrf = CSRFProtect(app)

# logging
handler = logging.FileHandler('running.log', encoding='UTF-8')
test = logging.FileHandler('test.log', encoding='UTF-8')
handler.setLevel(logging.DEBUG)
test.setLevel(logging.ERROR)
logging_format = logging.Formatter(
    '%(asctime)s - [line:%(lineno)d] - %(levelname)s: %(message)s')
testing_format = logging.Formatter(
    '%(asctime)s - %(pathname)s\\%(funcName)s[line:%(lineno)d] - %(levelname)s: %(message)s')
handler.setFormatter(logging_format)
test.setFormatter(testing_format)

app.logger.addHandler(handler)
app.logger.addHandler(test)


from . import views
from . import models
from . import apis

app.register_blueprint(apis.api)
csrf.exempt(apis.api)

