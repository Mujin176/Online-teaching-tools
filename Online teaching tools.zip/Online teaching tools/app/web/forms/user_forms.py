# coding: utf-8

from flask_wtf import FlaskForm
from wtforms import (
    DateField, StringField, TextAreaField,
    SelectMultipleField, SubmitField,
    PasswordField, BooleanField,
    DateTimeField, IntegerField, FloatField, SelectField,
    )
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError, NumberRange, Regexp
from flask_login import current_user
from ..models import user_models as models


class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(message='Username is required'),
        Length(max=32, min=5, message='Username accept 5--64 chars'),
        Regexp('^[A-Za-z][A-Za-z0-9_.]*$', 0,
               'Username is case-sensitive, consists of letters and digits, and leading char must be a letter.'
               ),
        ])
    email = StringField('Email', validators=[DataRequired(message='Email is required'),
        Email(message='Invalid email address')])
    role = SelectField('Role', choices=[('1', 'Student'), ('2', 'Teacher')], coerce=int, default='1')
    password = PasswordField('Password', validators=[
        DataRequired(), Length(6, max=32, message='Password accepts 6-32 chars')])
    password2 = PasswordField(
        'Password repeat', validators=[DataRequired(), EqualTo('password')])

    submit = SubmitField('Submit')

    def validate_username(self, name):
        user = models.User.query.filter_by(username=name.data).first()
        if user is not None:
            raise ValidationError('Username has been taken')

    def validate_email(self, email):
        if models.User.query.filter_by(email=email.data).first():
            raise ValidationError('Email has been occupied')


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[
        DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')


class ChangePasswordForm(FlaskForm):
    old_password = PasswordField('Old Password', validators=[DataRequired()])
    password = PasswordField('New Password', validators=[
        DataRequired(),
        Length(6, max=32, message='Accept 6-32 chars'),
        ])
    confirmPassword = PasswordField(
        'Password Repeat',
        validators=[DataRequired(), EqualTo('password', message='Does not match')])
    submit = SubmitField('Update Password')


class EditProfileForm(FlaskForm):
    fullname = StringField('Fullname', validators=[Length(0, 64)])
    about_me = TextAreaField('About Me')
    submit = SubmitField('Update Profile')


class UpdateAvatarForm(FlaskForm):
    avatar = FileField('Avatar', validators=[FileRequired(), FileAllowed(upload_set=['jpg', 'jpeg', 'png'], message='Only allow images')])
    submit = SubmitField('Update Avatar')


class PasswordResetRequestForm(FlaskForm):
    """
    request password reset when user forget password
    """
    email = StringField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Invalid email')])
    submit = SubmitField('Reset Password')


class PasswordResetForm(FlaskForm):
    """
    do reset password
    """
    password = PasswordField(
        'Password', validators=[
            DataRequired(message='Password is Required'),
            Length(min=6, message='Too Short. Please give me 6 chars at least.'),
            Length(max=32, message='Too Long. Password accepts 32 chars at most.'),
            ])
    confirmPassword = PasswordField(
        'Password Repeat', validators=[
            DataRequired(message='Password Repeat is required'),
            EqualTo('password', message='Does not match'),
            ])
    submit = SubmitField('Setup Password')
