# coding: utf-8
from flask_wtf import FlaskForm
from wtforms import (
    DateField, StringField, TextAreaField,
    SelectMultipleField, SubmitField,
    PasswordField, BooleanField,
    DateTimeField, IntegerField, FloatField, SelectField,
    )
from flask import g
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError, NumberRange, Regexp
from flask_login import current_user
from ..models import user_models as models
from ..models.lecture_models import Course
from flask_ckeditor import CKEditorField


class CourseCreateForm(FlaskForm):
    cover = FileField(label='Poster', validators=[FileRequired(), FileAllowed(['jpg', 'jpeg', 'png', 'gif'], message='Only accepts jpg/jpeg/png file')])
    name = StringField(label='Course Name', validators=[
        DataRequired(),
        Length(min=5, message='Too short. Please type 5 chars at least'),
        Length(max=128, message='Too Long. Accepts 128 chars at most'),
        ])
    code = StringField(label='Course Code', validators=[
        DataRequired(),
        Length(min=3, message='Too Short. Please type 3 chars at most'),
        Length(max=16, message='Too Long. Accepts 16 chars at most'),
        ])
    information = CKEditorField(validators=[DataRequired()])
    submit = SubmitField(label='Submit')

    def validate_code(self, code):
        try:

            obj: Course = g.course_obj
        except:
            obj: Course = None

        if obj is None:
            if Course.query.filter(Course.code == code.data).count():
                raise ValidationError(message='Course Code %s exists, please do not repeat.' % code.data, )
        else:
            oth: Course = Course.query.filter(Course.code == code.data).first()
            if oth is not None:
                if oth.code == obj.code:
                    pass
                else:
                    raise ValidationError(message='Course Code %s exists, please do not repeat.' % code.data, )


class CourseUpdateForm(CourseCreateForm):
    cover = FileField(label='Poster', validators=[
        FileAllowed(['jpg', 'jpeg', 'png', 'gif'], message='Only accepts jpg/jpeg/png file')])


class ResourceUploadForm(FlaskForm):
    kind = IntegerField(label='kind')
    course_id = IntegerField(label='course_id')
    file = FileField(label='Pdf File', validators=[
        FileRequired()])


class TopicCreateForm(FlaskForm):
    title = StringField(label='Title', validators=[
        DataRequired(),
        Length(min=10, message='Too short. Please type 10 chars at least.'),
        Length(max=128, message='Too Long. Accepts 128 chars at most.')])
    content = CKEditorField(validators=[DataRequired()])
    submit = SubmitField(label='Submit')
