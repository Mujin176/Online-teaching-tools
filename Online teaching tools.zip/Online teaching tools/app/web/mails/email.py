from threading import Thread
from flask import current_app, render_template
from flask_mail import Message
from .. import mail, app


def send_email(to, subject, text=None, html=None):
    """
    send email

    :param to: receiver's email address
    :param subject: email subject
    :param text: email content in plain txt
    :param html: email body in html
    :return:
    """
    with app.app_context():
        msg = Message(
            subject=app.config['FLASKY_MAIL_SUBJECT_PREFIX'] + ' ' + subject,
            sender=app.config['FLASKY_MAIL_SENDER'],
            recipients=[to],
            charset='utf-8'
            )
        msg.body = text
        msg.html = html

        with mail.connect() as conn:
            conn.send(msg)
        return True
