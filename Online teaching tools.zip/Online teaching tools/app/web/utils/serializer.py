# coding: utf-8
"""
https://docs.authlib.org/en/latest/jose/jwt.html
"""
from authlib.jose import JsonWebToken
from dataclasses import dataclass
from .common import get_utc_now

LIFE_TIME = 30 * 60  # 30Min


@dataclass
class JWTData:
    iss: int
    exp: int
    d: [list, dict, str, int]

    @classmethod
    def build(cls, data: [list, dict, str, int], life_time: int = None):
        """

        :param data:
        :param life_time:
        :return:
        """
        if not isinstance(data, (list, dict, str, int)):
            raise TypeError
        iss = int(get_utc_now().timestamp())
        if isinstance(life_time, int) and life_time > 0:
            pass
        else:
            life_time = LIFE_TIME
        exp = iss + life_time
        return cls(iss=iss, exp=exp, d=data)

    @classmethod
    def construct(cls, data):
        """

        :param data:
        :return:
        """
        if not isinstance(data, dict):
            raise TypeError

        iss = data.get('iss')
        exp = data.get('exp')
        d = data.get('d')

        if not isinstance(iss, int):
            raise ValueError
        if not isinstance(exp, int):
            raise ValueError
        if not isinstance(d, (list, dict, str, int)):
            raise ValueError
        return cls(iss=iss, exp=exp, d=d)

    @property
    def json(self):
        return {
            'iss': self.iss,
            'exp': self.exp,
            'd': self.d,
            }

    @property
    def is_expired(self):
        return self.exp < get_utc_now().timestamp()


def jwt_encode(payload: JWTData, key: str) -> str:
    """

    :param payload:
    :param key:
    :return:
    """
    if not isinstance(payload, JWTData):
        raise TypeError
    if not isinstance(key, str):
        raise TypeError
    return JsonWebToken().encode(header={'alg': 'HS256'}, payload=payload.json, key=key).decode('utf-8')


def jwt_decode(encrypted: str, key: str) -> JWTData:
    """

    :param encrypted:
    :param key:
    :return:
    """
    jwt = JsonWebToken()
    try:
        claims = jwt.decode(s=encrypted, key=key)
        print('c:', claims)
        return JWTData.construct(claims)
    except:
        pass




