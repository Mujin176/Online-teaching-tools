# coding: utf-8
from . import db, ModelBase
from .user_models import User
from ..utils.common import get_utc_now
from flask import url_for


class Course(ModelBase):
    __tablename__ = 'course'

    name = db.Column(db.String(128), nullable=False)
    code = db.Column(db.String(16), nullable=False)
    cover = db.Column(db.String(128), nullable=False)
    information = db.Column(db.Text(4096000000000), nullable=False)

    teacher_id = db.Column(db.Integer ,db.ForeignKey('user.id', ondelete='cascade'))
    teacher = db.relation('User', backref=db.backref('teach_course_list', cascade='all,delete, delete-orphan'))

    @property
    def cover_url(self):
        return url_for('media', file_path=self.cover)


class Skill(ModelBase):

    __tablename__ = 'skill'

    name = db.Column(db.String(128), nullable=False)

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='cascade'))
    course = db.relation(Course, backref=db.backref('skill_list', cascade='all,delete,delete-orphan'))


class Week(ModelBase):
    __tablename__ = 'week'

    no = db.Column(db.Integer, nullable=False)
    info = db.Column(db.Text, nullable=False)

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='cascade'))
    course = db.relation(Course, backref=db.backref('week_list', cascade='all,delete,delete-orphan'))


class WeekSkill(ModelBase):
    __tablename__ = 'weekSkill'

    skill_id = db.Column(db.Integer, db.ForeignKey('skill.id', ondelete='cascade'))
    skill = db.relation(Skill, backref=db.backref('week_skill_list', cascade='all,delete-orphan'))

    week_id = db.Column(db.Integer, db.ForeignKey('week.id', ondelete='cascade'))
    week = db.relation(Week, backref=db.backref('week_skill_list', cascade='all,delete-orphan'))


class Video(ModelBase):
    __tablename__ = 'video'
    name = db.Column(db.String(128), nullable=False)
    info = db.Column(db.Text, nullable=False)
    cover = db.Column(db.String(128), nullable=False)
    path = db.Column(db.String(128), nullable=False)

    week_id = db.Column(db.Integer, db.ForeignKey('week.id', ondelete='cascade'))
    week = db.relation(Week, backref=db.backref('video_list', cascade='all,delete,delete-orphan'))

    @property
    def cover_url(self):
        return url_for('media', file_path=self.cover)

    @property
    def video_url(self):
        return url_for('media', file_path=self.path)


class VideoSkill(ModelBase):
    __tablename__ = 'videoSkill'

    skill_id = db.Column(db.Integer, db.ForeignKey('skill.id', ondelete='cascade'))
    skill = db.relation(Skill, backref=db.backref('video_skill_list', cascade='all,delete-orphan'))

    video_id = db.Column(db.Integer, db.ForeignKey('video.id', ondelete='cascade'))
    video = db.relation(Video, backref=db.backref('video_skill_list', cascade='all,delete-orphan'))


class Attach(ModelBase):
    __tablename__ = 'attach'

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='cascade'), nullable=True)
    course = db.relation(Course, backref=db.backref('attach_list', cascade='all,delete,delete-orphan'))

    week_id = db.Column(db.Integer, db.ForeignKey('week.id', ondelete='cascade'), nullable=True)
    week = db.relation(Week, backref=db.backref('week_attach_list', cascade='all,delete-orphan'))

    video_id = db.Column(db.Integer, db.ForeignKey('video.id', ondelete='cascade'), nullable=True)
    video = db.relation(Video, backref=db.backref('video_attach_list', cascade='all,delete-orphan'))

    name = db.Column(db.String(128), nullable=False)
    path = db.Column(db.String(128), nullable=False)

    @property
    def attach_url(self):
        return url_for('media', file_path=self.path)

#
# class Resource(ModelBase):
#     __tablename__ = 'resource'
#
#     course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='cascade'))
#     course = db.relation(Course, backref=db.backref('resource_list', cascade='all,delete,delete-orphan'))
#     name = db.Column(db.String(128), nullable=False)
#     path = db.Column(db.String(128), nullable=False)
#
#     kind = db.Column(db.Integer, default=1)  # 1 readings(pdf) 2 slides(ppt)
#
#     @property
#     def url(self):
#         return url_for('media', file_path=self.path)


class Question(ModelBase):
    __tablename__ = 'question'

    stem = db.Column(db.Text, nullable=False)

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='cascade'), nullable=False)
    course = db.relation(Course, backref=db.backref('question_list', cascade='all,delete,delete-orphan'))

    week_id = db.Column(db.Integer, db.ForeignKey('week.id', ondelete='cascade'), nullable=True)
    week = db.relation(Week, backref=db.backref('question_list', cascade='all,delete,delete-orphan'))

    video_id = db.Column(db.Integer, db.ForeignKey('video.id', ondelete='cascade'), nullable=True)
    video = db.relation(Video, backref=db.backref('question_list', cascade='all,delete,delete-orphan'))

    is_bank = db.Column(db.Boolean, default=False, server_default='0')  # whether bank or assignment

    kind = db.Column(db.Integer, nullable=False, default=1)  # 2 select single # 1 judge  # 3 fill-in-blank
    score = db.Column(db.Integer, nullable=False, default=1)  # 1 - 10

    # is_correct = db.Column(db.Boolean, nullable=True)
    answer = db.Column(db.String(128), nullable=True)  # e.g. T/F 1,2 --- correct option-ids
    reason = db.Column(db.Text, nullable=True)

    @property
    def kind_name(self):
        if self.kind == 1:
            return 'True/False'
        elif self.kind == 2:
            return 'Multiple-Choices'
        elif self.kind == 3:
            return 'Blank-Filling'


class QuestionOption(ModelBase):

    __tablename__ = 'question_option'

    content = db.Column(db.Text)
    is_correct = db.Column(db.Boolean, default=False, nullable=False)

    question_id = db.Column(db.ForeignKey('question.id', ondelete='cascade'))
    question = db.relation(Question, backref=db.backref('option_list', cascade='all,delete,delete-orphan'))

    reason = db.Column(db.String(255), nullable=True)


class QuestionSkill(ModelBase):
    __tablename__ = 'questionSkill'

    question_id = db.Column(db.Integer, db.ForeignKey('question.id', ondelete='cascade'), nullable=True)
    question = db.relation(Question, backref=db.backref('question_skill_list', cascade='all,delete,delete-orphan'))

    skill_id = db.Column(db.Integer, db.ForeignKey('skill.id', ondelete='cascade'), nullable=True)
    skill = db.relation(Skill, backref=db.backref('question_skill_list', cascade='all,delete,delete-orphan'))


class JoinCourse(ModelBase):
    """
    student join course
    """
    __tablename__ = 'join_course'

    student_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'))
    student = db.relationship(User, backref=db.backref('student_joined_ls', cascade='all,delete,delete-orphan'))

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='CASCADE'), nullable=False)
    course = db.relationship('Course', backref=db.backref('student_joined_list', cascade='all,delete,delete-orphan'))

    is_finished = db.Column(db.Boolean, default=False, server_default='0', nullable=False)

    def __str__(self):
        return f'{self.student.name} joined {self.course.name}'

    def __repr__(self):
        return f'<JoinCourse {self.id} {self.__str__()}>'


class DoAssignment(ModelBase):
    """
    student do assignment
    """
    __tablename__ = 'do_assignment'

    student_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'))
    student = db.relationship(User, backref=db.backref('do_assignment_list', cascade='all,delete,delete-orphan'))

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='CASCADE'), nullable=False)
    course = db.relationship('Course', backref=db.backref('student_do_assignment_list', cascade='all,delete,delete-orphan'))

    week_id = db.Column(db.Integer, db.ForeignKey('week.id', ondelete='cascade'), nullable=True)
    week = db.relation(Week, backref=db.backref('week_do_assignment_list', cascade='all,delete,delete-orphan'))

    video_id = db.Column(db.Integer, db.ForeignKey('video.id', ondelete='cascade'), nullable=True)
    video = db.relation(Video, backref=db.backref('week_do_assignment_list', cascade='all,delete,delete-orphan'))

    is_homework = db.Column(db.Boolean, nullable=False, default=True)

    total_score = db.Column(db.Integer, nullable=False, default=0, server_default='0')
    student_score = db.Column(db.Integer, nullable=False, default=0, server_default='0')

    is_submitted = db.Column(db.Boolean, nullable=False, default=False)
    finished_at = db.Column(db.DateTime, nullable=True)


class Answer(ModelBase):
    """
    assignment record
    """

    __tablename__ = 'answer'

    do_assignment_id = db.Column(db.Integer, db.ForeignKey('do_assignment.id', ondelete='cascade'))
    do_assignment = db.relationship('DoAssignment', backref=db.backref('answer_list', cascade='all,delete,delete-orphan'))

    question_id = db.Column(db.ForeignKey('question.id', ondelete='cascade'))
    question = db.relation(Question, backref=db.backref('answer_list', cascade='all,delete,delete-orphan'))

    answer = db.Column(db.String(128), nullable=True)  # T/F // option_id // answer text
    score = db.Column(db.Integer, nullable=False, default=0)

    is_submitted = db.Column(db.Boolean, nullable=False, default=False)
    submitted_at = db.Column(db.DateTime, nullable=True)


related_comments_table = db.Table(
    'related_comment',
    db.Column('parent_id', db.Integer, db.ForeignKey('comment.id', ondelete='cascade')),
    db.Column('child_id', db.Integer, db.ForeignKey('comment.id', ondelete='cascade')),
    )


class Comment(ModelBase):
    """
    topic comments
    """
    __tablename__ = 'comment'

    kind = db.Column(db.String(16), nullable=False, default='no-kind', server_default='no-kind')
    parent_id = db.Column(db.Integer, nullable=False)

    id = db.Column(db.Integer, primary_key=True)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='cascade'), nullable=False)
    author = db.relationship('User', backref=db.backref('comment_list', cascade='all,delete,delete-orphan'))

    is_root = db.Column(db.Boolean, nullable=False, default=False)

    content = db.Column(db.Text, nullable=False)

    comments = db.relationship(
        'Comment', secondary=related_comments_table,
        primaryjoin=(related_comments_table.c.parent_id == id),
        secondaryjoin=(related_comments_table.c.child_id == id),
        lazy='dynamic',
        )


class LearnRecord(ModelBase):
    """

    """
    join_course_id = db.Column(db.Integer, db.ForeignKey('join_course.id', ondelete='cascade'))
    join_course = db.relation(JoinCourse, backref=db.backref('learn_record_ls', cascade='all,delete,delete-orphan'))

    student_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='cascade'))
    student = db.relation(User, backref=db.backref('learn_record_ls', cascade='all,delete,delete-orphan'))

    video_id = db.Column(db.Integer, db.ForeignKey('video.id', ondelete='cascade'))
    video = db.relation(Video, backref=db.backref('learn_record_ls', cascade='all,delete,delete-orphan'))

    video_watched = db.Column(db.Boolean, nullable=False, default=False, server_default='0')
    homework_done = db.Column(db.Boolean, nullable=False, default=False, server_default='0')


class LearnDuration(ModelBase):
    __tablename__ = 'learnDurationRecord'

    student_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='cascade'))
    student = db.relation(User, backref=db.backref('learn_duration_ls', cascade='all,delete,delete-orphan'))

    duration = db.Column(db.Float, nullable=False, default=0, server_default='0')

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='CASCADE'), nullable=False)
    course = db.relationship('Course',
                             backref=db.backref('learn_duration_ls', cascade='all,delete,delete-orphan'))

    week_id = db.Column(db.Integer, db.ForeignKey('week.id', ondelete='cascade'), nullable=True)
    week = db.relation(Week, backref=db.backref('learn_duration_ls', cascade='all,delete,delete-orphan'))

    video_id = db.Column(db.Integer, db.ForeignKey('video.id', ondelete='cascade'), nullable=True)
    video = db.relation(Video, backref=db.backref('learn_duration_ls', cascade='all,delete,delete-orphan'))


class MissedCheckIn(ModelBase):
    __tablename__ = 'missed'

    student_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='cascade'))
    student = db.relation(User, backref=db.backref('missed_ls', cascade='all,delete,delete-orphan'))

    course_id = db.Column(db.Integer, db.ForeignKey('course.id', ondelete='CASCADE'), nullable=False)
    course = db.relationship('Course', backref=db.backref('missed_ls', cascade='all,delete,delete-orphan'))

    week_id = db.Column(db.Integer, db.ForeignKey('week.id', ondelete='cascade'), nullable=True)
    week = db.relation(Week, backref=db.backref('missed_ls', cascade='all,delete,delete-orphan'))

    video_id = db.Column(db.Integer, db.ForeignKey('video.id', ondelete='cascade'), nullable=True)
    video = db.relation(Video, backref=db.backref('missed_ls', cascade='all,delete,delete-orphan'))
