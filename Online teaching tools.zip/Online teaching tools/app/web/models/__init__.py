# coding: utf-8
from .. import db, flask_bcrypt, login
from ..utils.common import get_utc_now


class ModelBase(db.Model):
    __abstract__ = True
    id = db.Column(db.Integer, primary_key=True)

    created_at = db.Column(db.DateTime, default=lambda: get_utc_now().replace(tzinfo=None))
    updated_at = db.Column(db.DateTime,
                           default=lambda: get_utc_now().replace(tzinfo=None),
                           onupdate=lambda: get_utc_now().replace(tzinfo=None))

    def __repr__(self):
        return '<{}: {}>'.format(self.__class__.__name__, getattr(self, 'id', 'None'))


from . import user_models
from . import lecture_models
