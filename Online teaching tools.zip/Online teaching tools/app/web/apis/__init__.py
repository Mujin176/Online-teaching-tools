# coding: utf-8
from flask import Blueprint
from functools import wraps
from flask import request, jsonify

api_version = 'v1'

api = Blueprint('api', __name__, url_prefix=f'/api/{api_version}')


from . import course_api
