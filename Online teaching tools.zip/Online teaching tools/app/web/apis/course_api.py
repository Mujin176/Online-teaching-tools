# coding: utf-8
import os

from . import api
from ..models import db
from ..models.lecture_models import (
    Course, Question, QuestionOption,
    JoinCourse, DoAssignment, Answer, Comment, Skill, WeekSkill, Week, Video, VideoSkill, Attach,
    QuestionSkill, LearnRecord, LearnDuration, MissedCheckIn
    )
from ..models.user_models import User
from flask_login import current_user, login_required
from flask import (request, render_template, jsonify, flash, g, redirect, url_for, abort)
from ..forms.lecture_forms import (
    CourseCreateForm, TopicCreateForm, CourseUpdateForm, ResourceUploadForm
    )
from config import media_dir
from datetime import datetime, timedelta
from ..utils.common import save_file, paginate_helper, get_utc_now
import json


def get_form_value(name: str, is_file: bool = False, multi_files: bool = False):
    if is_file:
        if multi_files:
            return request.files.getlist(name)
        return request.files.get(name)
    else:
        return request.form.get(name)


def delete_file(rel_path):
    fp = media_dir / rel_path
    if fp.exists() and fp.is_file():
        os.remove(fp)


def course_create_or_update():
    course_id = get_form_value('course_id')
    name = get_form_value('name')
    code = get_form_value('code')
    file = get_form_value('cover', is_file=True)

    if course_id is None:
        course_obj = Course()
    else:
        course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
        if course_obj is None:
            return jsonify(success=False, msg='course is missing or you do not own this course')

    if file is not None:
        day = datetime.now().strftime('%Y-%m-%d')
        dir_path = media_dir / 'course' / day
        fp = save_file(file_obj=file, dir_path=dir_path)
        cover_path = '/'.join(fp.relative_to(media_dir).parts)
        course_obj.cover = cover_path

    information = get_form_value('information')
    teacher_id = current_user.id

    course_obj.name = name
    course_obj.code = code

    course_obj.information = information
    course_obj.teacher_id = teacher_id
    db.session.add(course_obj)
    db.session.commit()
    new_skills = get_form_value('new_skills')
    if new_skills:
        new_skills = json.loads(new_skills)
    else:
        new_skills = []
    for s in new_skills:
        skill_obj = Skill()
        skill_obj.name = s
        skill_obj.course_id = course_obj.id
        db.session.add(skill_obj)
        db.session.commit()

    old_skills = get_form_value('old_skills')
    if old_skills:
        old_skills = json.loads(old_skills)
    else:
        old_skills = []
    for it in old_skills:
        skill_obj = Skill.query.filter(Skill.course_id == course_obj.id).filter(Skill.id == it['id']).first()
        if skill_obj is not None:
            if skill_obj.name != it['name']:
                skill_obj.name = it['name']
                db.session.add(skill_obj)
                db.session.commit()

    # attaches
    attaches = []
    t = 0
    while True:
        att = get_form_value(f'attach_{t}', is_file=True)
        if att is None:
            break
        attaches.append(att)
        t += 1
    for att in attaches:
        day = datetime.now().strftime('%Y-%m-%d')
        dir_path = media_dir / 'course-attach' / day
        fp = save_file(file_obj=att, dir_path=dir_path)
        att_path = '/'.join(fp.relative_to(media_dir).parts)

        att_obj = Attach()
        att_obj.course_id = course_obj.id
        att_obj.name = att.filename
        att_obj.path = att_path
        db.session.add(att_obj)
        db.session.commit()

    return jsonify(success=True, data={'course_id': course_obj.id})


@login_required
@api.route('/course/create', methods=['post'])
def course_create():
    """

    :return:
    """
    return course_create_or_update()


@login_required
@api.route('/course/update', methods=['post'])
def course_update():
    """

    :return:
    """
    return course_create_or_update()


@api.route('/course/info', methods=['post'])
def course_info():
    results = {}

    course_id = get_form_value('course_id')
    actions = get_form_value('actions') or '[]'

    course_obj = Course.query.filter(Course.id == course_id).first()
    for k in json.loads(actions):
        if k == 'skills':
            ls = []
            for sk in Skill.query.filter(Skill.course_id == course_id).order_by(Skill.created_at.desc()).all():
                ls.append({'id': sk.id, 'name': sk.name})
            results[k] = ls
        elif k == 'videos':
            week_id = get_form_value('week_id')
            if week_id is None:
                return jsonify(success=False, msg='week_id is required')
            week_obj = Week.query.filter(Week.id == week_id).filter(Week.course_id == course_obj.id).first()
            if week_obj is None:
                return jsonify(success=False, msg='week did not exist')
            ls = []
            for sk in Skill.query.join(WeekSkill, WeekSkill.skill_id == Skill.id).filter(WeekSkill.week_id == week_obj.id).all():
                ls.append({'id': sk.id, 'name': sk.name})
            results[k] = ls
        else:
            return jsonify(success=False, msg='invalid actions')

    return jsonify(success=True, data=results)


def week_create_or_update():
    course_id = get_form_value('course_id')
    # todo validate user owns this course
    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course_id is required')

    no = get_form_value('no')
    info = get_form_value('information')

    week_id = get_form_value('week_id')

    if week_id is None:
        week_obj = Week()
    else:
        week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
        if week_obj is None:
            return jsonify(success=False, msg="week is missing")

    week_obj.course_id = course_id
    week_obj.no = no
    week_obj.info = info
    db.session.add(week_obj)
    db.session.commit()

    # week skill id list
    skill_id_ls = []

    # new skills
    new_skills = get_form_value('new_skills')
    if new_skills:
        new_skills = json.loads(new_skills)
    else:
        new_skills = []
    for s in new_skills:
        skill_obj = Skill()
        skill_obj.name = s
        skill_obj.course_id = course_id
        db.session.add(skill_obj)
        db.session.commit()
        skill_id_ls.append(skill_obj.id)

    old_skills = get_form_value('old_skills')
    if old_skills:
        old_skills = json.loads(old_skills)
    else:
        old_skills = []
    for it in old_skills:
        skill_obj = Skill.query.filter(Skill.course_id == course_obj.id).filter(Skill.id == it['id']).first()
        if skill_obj is not None:
            skill_id_ls.append(skill_obj.id)
            if skill_obj.name != it['name']:
                skill_obj.name = it['name']
                db.session.add(skill_obj)
                db.session.commit()

    # skill already tagged with this week_obj
    existing = []
    for i, in db.session.query(WeekSkill.skill_id).filter(WeekSkill.week_id == week_obj.id).all():
        existing.append(i)

    for skid in skill_id_ls:
        if skid in existing:
            continue
        week_skill_obj = WeekSkill()
        week_skill_obj.week_id = week_obj.id
        week_skill_obj.skill_id = skid
        db.session.add(week_skill_obj)
        db.session.commit()

    # attaches
    attaches = []
    t = 0
    while True:
        att = get_form_value(f'attach_{t}', is_file=True)
        if att is None:
            break
        t += 1
        attaches.append(att)
    for att in attaches:
        day = datetime.now().strftime('%Y-%m-%d')
        dir_path = media_dir / 'course-week-attach' / day
        fp = save_file(file_obj=att, dir_path=dir_path)
        att_path = '/'.join(fp.relative_to(media_dir).parts)

        att_obj = Attach()
        att_obj.week_id = week_obj.id
        att_obj.name = att.filename
        att_obj.path = att_path
        db.session.add(att_obj)
        db.session.commit()

    return jsonify(success=True, data={'week_id': week_obj.id})


@api.route('/course/week/create', methods=['post'])
@login_required
def week_create():
    """

    :return:
    """
    return week_create_or_update()


@api.route('/course/week/update', methods=['post'])
@login_required
def week_update():
    """

    :return:
    """
    return week_create_or_update()


@api.route('/course/skill/delete', methods=['delete'])
@login_required
def skill_delete():
    """

    :return:
    """
    course_id = get_form_value('course_id')
    skill_id = get_form_value('skill_id')
    pos = get_form_value('pos')

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()

    if course_obj is None:
        return jsonify(success=False, msg='The course did not exist, or you do not own this course.')

    skill_obj = Skill.query.filter(Skill.course_id==course_obj.id).filter(Skill.id == skill_id).first()
    if skill_obj is None:
        return jsonify(success=False, msg='Skill did not exist.')

    if pos == 'course':
        db.session.delete(skill_obj)
        db.session.commit()
    elif pos == 'week':
        week_id = get_form_value('week_id')
        if week_id is None:
            return jsonify(success=False, msg='Skill id is required')
        db.session.query(WeekSkill).filter(WeekSkill.week_id == week_id).filter(WeekSkill.skill_id == skill_id).delete()
        db.session.commit()
    elif pos == 'video':
        video_id = get_form_value('video_id')
        if video_id is None:
            return jsonify(success=False, msg='video id is required')
        db.session.query(VideoSkill).filter(VideoSkill.video_id == video_id).filter(VideoSkill.skill_id == skill_id).delete()
        db.session.commit()
    else:
        return jsonify(success=False, msg='invalid operation')
    return jsonify(success=True)


def video_update_or_create():
    course_id = get_form_value('course_id')
    if course_id is None:
        return jsonify(success=False, msg='course_id is required'), 404

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course is missing'), 404

    week_id = get_form_value('week_id')
    week_obj = Week.query.filter(Week.id == week_id).filter(Week.course_id == course_id).first()
    if week_obj is None:
        return jsonify(success=False, msg='week_id is required'), 404

    video_id = get_form_value('video_id')
    cover_file = get_form_value('cover', is_file=True)
    video_file = get_form_value('video', is_file=True)

    if video_id is None:
        if cover_file is None or video_file is None:
            return jsonify(success=False, msg='poster and video files are required')
        video_obj = Video()
        video_obj.week_id = week_obj.id
    else:
        video_obj = Video.query.filter(Video.week_id == week_obj.id).filter(Video.id == video_id).first()
        if video_obj is None:
            return jsonify(success=False, msg='video_id is required'), 404
        if video_file is not None:
            delete_file(rel_path=video_obj.path)
        if cover_file is not None:
            delete_file(rel_path=video_obj.cover)

    info = get_form_value('information')
    day = datetime.now().strftime('%Y-%m-%d')

    if cover_file is not None:
        dir_path = media_dir / 'video-cover' / day
        fp = save_file(file_obj=cover_file, dir_path=dir_path)
        cover_path = '/'.join(fp.relative_to(media_dir).parts)
        video_obj.cover = cover_path

    if video_file is not None:
        video_filename = video_file.filename
        dir_path = media_dir / 'video' / day
        fp = save_file(file_obj=video_file, dir_path=dir_path)
        video_path = '/'.join(fp.relative_to(media_dir).parts)
        video_obj.name = video_filename
        video_obj.path = video_path

    video_obj.info = info

    db.session.add(video_obj)
    db.session.commit()

    # week skill id list
    skill_id_ls = []

    # new skills
    new_skills = get_form_value('new_skills')
    if new_skills:
        new_skills = json.loads(new_skills)
    else:
        new_skills = []
    for s in new_skills:
        skill_obj = Skill()
        skill_obj.name = s
        skill_obj.course_id = course_id
        db.session.add(skill_obj)
        db.session.commit()
        skill_id_ls.append(skill_obj.id)

    old_skills = get_form_value('old_skills')
    if old_skills:
        old_skills = json.loads(old_skills)
    else:
        old_skills = []
    for it in old_skills:
        skill_obj = Skill.query.filter(Skill.course_id == course_obj.id).filter(Skill.id == it['id']).first()
        if skill_obj is not None:
            skill_id_ls.append(skill_obj.id)
            if skill_obj.name != it['name']:
                skill_obj.name = it['name']
                db.session.add(skill_obj)
                db.session.commit()

    # skill already tagged with this week_obj
    existing = []
    for i, in db.session.query(VideoSkill.skill_id).filter(VideoSkill.video_id == video_obj.id).all():
        existing.append(i)

    for skid in skill_id_ls:
        if skid in existing:
            continue
        video_skill_obj = VideoSkill()
        video_skill_obj.video_id = video_obj.id
        video_skill_obj.skill_id = skid
        db.session.add(video_skill_obj)
        db.session.commit()

    # week skills
    existing_skills_of_video = []
    for i, in db.session.query(VideoSkill.skill_id).filter(VideoSkill.video_id == video_obj.id).all():
        existing_skills_of_video.append(i)
    existing_skills_of_week = []
    for i, in db.session.query(WeekSkill.skill_id).filter(WeekSkill.week_id == week_obj.id).all():
        existing_skills_of_week.append(i)

    for skid in existing_skills_of_video:
        if skid in existing_skills_of_week:
            continue
        week_skill_obj = WeekSkill()
        week_skill_obj.week_id = week_obj.id
        week_skill_obj.skill_id = skid
        db.session.add(week_skill_obj)
        db.session.commit()

    # attaches
    attaches = []
    t = 0
    while True:
        att = get_form_value(f'attach_{t}', is_file=True)
        if att is None:
            break
        t += 1
        attaches.append(att)
    for att in attaches:
        day = datetime.now().strftime('%Y-%m-%d')
        dir_path = media_dir / 'course-video-attach' / day
        fp = save_file(file_obj=att, dir_path=dir_path)
        att_path = '/'.join(fp.relative_to(media_dir).parts)

        att_obj = Attach()
        att_obj.video_id = video_obj.id
        att_obj.name = att.filename
        att_obj.path = att_path
        db.session.add(att_obj)
        db.session.commit()

    return jsonify(success=True, data={'video_id': video_obj.id})


@api.route('/course/video/create', methods=['post'])
@login_required
def video_create():
    """

    :return:
    """
    # course_id = get_form_value('course_id')
    # if course_id is None:
    #     return jsonify(success=False, msg='course_id is required'), 404
    #
    # course_obj = Course.query.filter(
    #     Course.id == course_id).filter(
    #     Course.teacher_id == current_user.id).first()
    # if course_obj is None:
    #     return jsonify(success=False, msg='course is missing'), 404
    #
    # week_id = get_form_value('week_id')
    # week_obj = Week.query.filter(Week.id == week_id).filter(Week.course_id == course_id).first()
    # if week_obj is None:
    #     return jsonify(success=False, msg='week_id is required'), 404
    #
    # info = get_form_value('information')
    #
    # cover_file = get_form_value('cover', is_file=True)
    # day = datetime.now().strftime('%Y-%m-%d')
    # dir_path = media_dir / 'video-cover' / day
    # fp = save_file(file_obj=cover_file, dir_path=dir_path)
    # cover_path = '/'.join(fp.relative_to(media_dir).parts)
    #
    # video_file = get_form_value('video', is_file=True)
    # video_filename = video_file.filename
    # dir_path = media_dir / 'video' / day
    # fp = save_file(file_obj=video_file, dir_path=dir_path)
    # video_path = '/'.join(fp.relative_to(media_dir).parts)
    #
    # video_obj = Video()
    # video_obj.week_id = week_obj.id
    # video_obj.name = video_filename
    # video_obj.info = info
    # video_obj.cover = cover_path
    # video_obj.path = video_path
    # db.session.add(video_obj)
    # db.session.commit()
    #
    # # week skill id list
    # skill_id_ls = []
    #
    # # new skills
    # new_skills = get_form_value('new_skills')
    # if new_skills:
    #     new_skills = json.loads(new_skills)
    # else:
    #     new_skills = []
    # for s in new_skills:
    #     skill_obj = Skill()
    #     skill_obj.name = s
    #     skill_obj.course_id = course_id
    #     db.session.add(skill_obj)
    #     db.session.commit()
    #     skill_id_ls.append(skill_obj.id)
    #
    # old_skills = get_form_value('old_skills')
    # if old_skills:
    #     old_skills = json.loads(old_skills)
    # else:
    #     old_skills = []
    # for it in old_skills:
    #     skill_obj = Skill.query.filter(
    #         Skill.course_id == course_obj.id).filter(
    #         Skill.id == it['id']).first()
    #     if skill_obj is not None:
    #         skill_id_ls.append(skill_obj.id)
    #         if skill_obj.name != it['name']:
    #             skill_obj.name = it['name']
    #             db.session.add(skill_obj)
    #             db.session.commit()
    #
    # # skill already tagged with this week_obj
    # existing = []
    # for i, in db.session.query(VideoSkill.skill_id).filter(VideoSkill.video_id == video_obj.id).all():
    #     existing.append(i)
    #
    # for skid in skill_id_ls:
    #     if skid in existing:
    #         continue
    #     video_skill_obj = VideoSkill()
    #     video_skill_obj.video_id = video_obj.id
    #     video_skill_obj.skill_id = skid
    #     db.session.add(video_skill_obj)
    #     db.session.commit()
    #
    # # week skills
    # existing_skills_of_video = []
    # for i, in db.session.query(VideoSkill.skill_id).filter(VideoSkill.video_id == video_obj.id).all():
    #     existing_skills_of_video.append(i)
    # existing_skills_of_week = []
    # for i, in db.session.query(WeekSkill.skill_id).filter(WeekSkill.week_id == week_obj.id).all():
    #     existing_skills_of_week.append(i)
    #
    # for skid in existing_skills_of_video:
    #     if skid in existing_skills_of_week:
    #         continue
    #     week_skill_obj = WeekSkill()
    #     week_skill_obj.week_id = week_obj.id
    #     week_skill_obj.skill_id = skid
    #     db.session.add(week_skill_obj)
    #     db.session.commit()
    #
    # # attaches
    # attaches = []
    # t = 0
    # while True:
    #     att = get_form_value(f'attach_{t}', is_file=True)
    #     if att is None:
    #         break
    #     t += 1
    #     attaches.append(att)
    # for att in attaches:
    #     day = datetime.now().strftime('%Y-%m-%d')
    #     dir_path = media_dir / 'course-video-attach' / day
    #     fp = save_file(file_obj=att, dir_path=dir_path)
    #     att_path = '/'.join(fp.relative_to(media_dir).parts)
    #
    #     att_obj = Attach()
    #     att_obj.video_id = video_obj.id
    #     att_obj.name = att.filename
    #     att_obj.path = att_path
    #     db.session.add(att_obj)
    #     db.session.commit()
    #
    # return jsonify(success=True, data={'video_id': video_obj.id})
    return video_update_or_create()


@api.route('/course/video/update', methods=['post'])
@login_required
def video_update():
    return video_update_or_create()


def question_create_or_update():
    """

    :return:
    """
    stem = get_form_value('stem')
    course_id = get_form_value('course_id')
    week_id = get_form_value('week_id')
    video_id = get_form_value('video_id')
    kind = get_form_value('kind')
    score = get_form_value('score')
    answer = get_form_value('answer')
    reason = get_form_value('reason')
    skills = get_form_value('skills')

    if not stem:
        return jsonify(success=False)

    if not score:
        return jsonify(success=False)
    try:
        score = int(score)
    except (TypeError, ValueError):
        return jsonify(success=False)
    if score < 1 or score > 10:
        return jsonify(success=False)

    if not reason:
        return jsonify(success=False)

    if skills is None:
        return jsonify(success=False)
    try:
        skills = json.loads(skills)
    except json.JSONDecodeError:
        return jsonify(success=False)

    if not isinstance(skills, list):
        return jsonify(success=False)

    question_id = get_form_value('question_id')
    if question_id and question_id != '0':
        question_obj = Question.query.filter(Question.id == question_id).first()
        if question_obj is None:
            return jsonify(success=False, msg='Question did not exist')
    else:
        question_obj = Question()

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course did not exist')

    if week_id is None or week_id == '0':
        is_bank = True
        all_skills = []
        for i, in db.session.query(Skill.id).filter(Skill.course_id == course_obj.id).all():
            all_skills.append(str(i))
        if len(set(skills) - set(all_skills)) > 0:
            return jsonify(success=False, msg='Invalid operation, please refresh this page')
        week_id = None
        video_id = None

        if question_obj.id:
            if question_obj.course_id != course_obj.id:
                return jsonify(success=False, msg='Invalid operation, please check you data, or refresh this page and try again.')

    else:
        is_bank = False
        week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == course_id).first()
        if week_obj is None:
            return jsonify(success=False, msg='week did not exist')
        video_obj = Video.query.filter(Video.week_id == week_obj.id).filter(Video.id == video_id).first()
        if video_obj is None:
            return jsonify(success=False, msg='video not exist.')

        all_skills = []
        for i, in db.session.query(VideoSkill.skill_id).filter(VideoSkill.video_id == video_obj.id).all():
            all_skills.append(str(i))

        if len(set(skills) - set(all_skills)) > 0:
            return jsonify(success=False, msg='Invalid operation, please refresh this page and try again')

        if question_obj.id:
            if question_obj.course_id != course_obj.id or question_obj.week_id != week_obj.id or question_obj.video_id != video_obj.id:
                return jsonify(success=False, msg='Invalid operation, data validation failed')

    question_obj.stem = stem
    question_obj.course_id = course_id
    question_obj.week_id = week_id
    question_obj.is_bank = is_bank
    question_obj.video_id = video_id

    question_obj.score = score
    question_obj.answer = answer
    question_obj.reason = reason

    options = []
    if kind == 'judge':
        kind = 1
        if answer not in ['T', 'F']:
            return jsonify(success=False, msg='invalid operation, answer expected to be T/F')
    elif kind == 'fill':
        kind = 3
        if not answer:
            return jsonify(success=False, msg='answer is required')
    elif kind == 'choices':
        kind = 2
        option_a = get_form_value('optionA')
        option_b = get_form_value('optionB')
        option_c = get_form_value('optionC')
        option_d = get_form_value('optionD')

        if not option_a:
            return jsonify(success=False, msg='Option a is required')

        if not option_b:
            return jsonify(success=False, msg='Option b is required')

        if not option_c:
            return jsonify(success=False, msg='Option c is required')

        if not option_d:
            return jsonify(success=False, msg='Option d is required')
        print(f"`{answer}`", type(answer), answer not in ['0', '1', '2', '3'])
        if answer not in ['0', '1', '2', '3']:
            return jsonify(success=False, msg='Invalid operation'), 400

        options = [option_a, option_b, option_c, option_d]
        answer = int(answer)
    else:
        return jsonify(success=False, msg='invalid question type')

    question_obj.kind = kind
    db.session.add(question_obj)
    db.session.commit()

    # operations
    db.session.query(QuestionOption).filter(QuestionOption.question_id == question_obj.id).delete()
    db.session.commit()
    for index, content in enumerate(options):
        is_correct = index == answer

        question_option_obj = QuestionOption()
        question_option_obj.question_id = question_obj.id
        question_option_obj.content = content
        question_option_obj.is_correct = is_correct
        question_option_obj.reason = reason

        db.session.add(question_option_obj)
        db.session.commit()

    # skills
    db.session.query(QuestionSkill).filter(QuestionSkill.question_id == question_obj.id).delete()
    db.session.commit()
    for skid in skills:
        question_skill_obj = QuestionSkill()
        question_skill_obj.question_id = question_obj.id
        question_skill_obj.skill_id = skid
        db.session.add(question_skill_obj)
        db.session.commit()

    return jsonify(success=True, data={'question_id': question_obj.id})


@api.route('/course/question/create', methods=['post'])
@login_required
def question_create():
    """

    :return:
    """
    # stem = get_form_value('stem')
    # course_id = get_form_value('course_id')
    # week_id = get_form_value('week_id')
    # video_id = get_form_value('video_id')
    # kind = get_form_value('kind')
    # score = get_form_value('score')
    # answer = get_form_value('answer')
    # reason = get_form_value('reason')
    # skills = get_form_value('skills')
    #
    # if not stem:
    #     return jsonify(success=False)
    #
    # if not score:
    #     return jsonify(success=False)
    # try:
    #     score = int(score)
    # except (TypeError, ValueError):
    #     return jsonify(success=False)
    # if score < 1 or score > 10:
    #     return jsonify(success=False)
    #
    # if not reason:
    #     return jsonify(success=False)
    #
    # if skills is None:
    #     return jsonify(success=False)
    # try:
    #     skills = json.loads(skills)
    # except json.JSONDecodeError:
    #     return jsonify(success=False)
    #
    # if not isinstance(skills, list):
    #     return jsonify(success=False)
    #
    # course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    # if course_obj is None:
    #     return jsonify(success=False)
    #
    # if week_id == '0':
    #     is_bank = True
    #     all_skills = []
    #     for i, in db.session.query.filter(Skill.id).filter(Skill.course_id == course_obj.id).all():
    #         all_skills.append(str(i))
    #     if len(set(skills) - set(all_skills)) > 0:
    #         return jsonify(success=False)
    #     week_id = None
    #     video_id = None
    # else:
    #     is_bank = False
    #     week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == course_id).first()
    #     if week_obj is None:
    #         return jsonify(success=False)
    #     video_obj = Video.query.filter(Video.week_id == week_obj.id).filter(Video.id == video_id).first()
    #     if video_obj is None:
    #         return jsonify(success=False)
    #
    #     all_skills = []
    #     for i, in db.session.query(VideoSkill.skill_id).filter(VideoSkill.video_id == video_obj.id).all():
    #         all_skills.append(str(i))
    #
    #     if len(set(skills) - set(all_skills)) > 0:
    #         return jsonify(success=False)
    #
    # question_obj = Question()
    # question_obj.stem = stem
    # question_obj.course_id = course_id
    # question_obj.week_id = week_id
    # question_obj.is_bank = is_bank
    #
    # question_obj.score = score
    # question_obj.answer = answer
    # question_obj.reason = reason
    #
    # options = []
    # if kind == 'judge':
    #     kind = 1
    #     if answer not in ['T', 'F']:
    #         return jsonify(success=False)
    # elif kind == 'fill':
    #     kind = 3
    #     if not answer:
    #         return jsonify(success=False)
    # elif kind == 'choices':
    #     kind = 2
    #     option_a = get_form_value('optionA')
    #     option_b = get_form_value('optionB')
    #     option_c = get_form_value('optionC')
    #     option_d = get_form_value('optionD')
    #
    #     if not option_a:
    #         return jsonify(success=False)
    #
    #     if not option_b:
    #         return jsonify(success=False)
    #
    #     if not option_c:
    #         return jsonify(success=False)
    #
    #     if not option_d:
    #         return jsonify(success=False)
    #
    #     if answer not in ['0', '1', '2', '3']:
    #         return jsonify(success=False)
    #
    #     options = [option_a, option_b, option_c, option_d]
    #     answer = int(answer)
    # else:
    #     return jsonify(success=False)
    #
    # question_obj.kind = kind
    # db.session.add(question_obj)
    # db.session.commit()
    #
    # for index, content in enumerate(options):
    #     is_correct = index == answer
    #
    #     question_option_obj = QuestionOption()
    #     question_option_obj.question_id = question_obj.id
    #     question_option_obj.content = content
    #     question_option_obj.is_correct = is_correct
    #     question_option_obj.reason = reason
    #
    #     db.session.add(question_option_obj)
    #     db.session.commit()
    #
    # # skills
    # for skid in skills:
    #     question_skill_obj = QuestionSkill()
    #     question_skill_obj.question_id = question_obj.id
    #     question_skill_obj.skill_id = skid
    #     db.session.add(question_skill_obj)
    #     db.session.commit()
    #
    # return jsonify(success=True, data={'question_id': question_obj.id})
    return question_create_or_update()


@api.route('/course/question/update', methods=['post'])
@login_required
def question_update():
    return question_create_or_update()


@login_required
@api.route('/course/skill/create', methods=['post'])
def skill_create():
    name = get_form_value('name')
    course_id = get_form_value('course_id')
    week_id = get_form_value('week_id')
    video_id = get_form_value('video_id')

    if course_id is None:
        # todo
        pass
    else:
        course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
        if course_obj is None:
            return jsonify(success=False, msg='Course did not exist')
        skill_obj = Skill()
        skill_obj.course_id = course_id
        skill_obj.name = name
        db.session.add(skill_obj)
        db.session.commit()
        return jsonify(success=True, data={'skill_id': skill_obj.id})

@login_required
@api.route('/course/skill/update', methods=['post'])
def skill_update():
    name = get_form_value('name')
    skill_id = get_form_value('skill_id')
    course_id = get_form_value('course_id')

    if name is None:
        return jsonify(success=False, msg='skill content is required')
    elif len(name) < 3:
        return jsonify(success=False, msg='skill content too short, accept 3 chars at least')
    elif len(name) > 128:
        return jsonify(success=False, msg='skill content too long, accept 128 chars at most')

    if skill_id is None:
        abort(500)

    if course_id is None:
        abort(500)

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False, msg='Courser did not exits'), 404

    skill_obj = Skill.query.filter(Skill.id == skill_id).filter(Skill.course_id == course_id).first()
    if skill_obj is None:
        return jsonify(success=False, msg='skill did not exist'), 404

    skill_obj.name = name
    db.session.add(skill_obj)
    db.session.commit()
    return jsonify(success=True)


@login_required
@api.route('/course/attach/delete', methods=['delete'])
def attach_delete():
    """
    delete attach file and database record
    :return:
    """
    attach_id = get_form_value('attach_id')
    course_id = get_form_value('course_id')
    pos = get_form_value('pos')
    if attach_id is None:
        abort(500)

    if course_id is None:
        abort(500)

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False, msg='Courser did not exits'), 404

    attach_obj: Attach = Attach.query.filter(Attach.id == attach_id).first()
    if attach_obj is None:
        return jsonify(success=True, msg='attach did not exist')

    if pos == 'course':
        if attach_obj.course_id != course_obj.id:
            abort(500)

    elif pos == 'week':
        week_id = get_form_value('week_id')
        week_obj = Week.query.filter(Week.id == week_id).filter(Week.course_id == course_obj.id).first()
        if week_obj is None:
            abort(500)
        if attach_obj.week_id != week_obj.id:
            abort(500)

    elif pos == 'video':
        video_id = get_form_value('video_id')
        week_id = get_form_value('week_id')
        week_obj = Week.query.filter(Week.id == week_id).filter(Week.course_id == course_obj.id).first()
        if week_obj is None:
            abort(500)
        video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
        if video_obj is None:
            abort(500)
        if attach_obj.video_id != video_obj.id:
            abort(500)
    else:
        abort(500)

    to_delete = media_dir / attach_obj.path
    db.session.delete(attach_obj)
    db.session.commit()
    if to_delete.exists():
        os.remove(to_delete)

    return jsonify(success=True)


def delete_item(item):
    """

    :return:
    """
    if type(item) == Attach:
        # delete attach obj
        attach_obj: Attach = item
        delete_file(attach_obj.path)
        db.session.delete(attach_obj)
        db.session.commit()
    elif type(item) == Video:
        video_obj = item
        for attach_obj in Attach.query.filter(Attach.video_id == video_obj.id).all():
            delete_item(attach_obj)
        delete_file(video_obj.cover)
        delete_file(video_obj.path)
        db.session.delete(video_obj)
        db.session.commit()
    elif type(item) == Week:
        week_obj = item
        for attach_obj in Attach.query.filter(Attach.week_id == week_obj.id).all():
            delete_item(attach_obj)
        for video_obj in Video.query.filter(Video.week_id == week_obj.id).all():
            delete_item(video_obj)
        db.session.delete(week_obj)
        db.session.commit()
    elif type(item) == Course:
        course_obj = item
        for attach_obj in Attach.query.filter(Attach.course_id == course_obj.id).all():
            delete_item(attach_obj)
        for week_obj in Week.query.filter(Week.course_id == course_obj.id).all():
            delete_item(week_obj)
        db.session.delete(course_obj)
        db.session.commit()


@login_required
@api.route('/course/week/delete', methods=['delete'])
def week_delete():
    """

    :return:
    """
    week_id = get_form_value('week_id')
    course_id = get_form_value('course_id')

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False)
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    if week_obj is None:
        return jsonify(success=False)

    delete_item(week_obj)
    return jsonify(success=True)


@login_required
@api.route('/course/video/delete', methods=['delete'])
def video_delete():
    """

    :return:
    """
    video_id = get_form_value('video_id')
    week_id = get_form_value('week_id')
    course_id = get_form_value('course_id')

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False)
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    if week_obj is None:
        return jsonify(success=False)
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    if video_obj is None:
        return jsonify(success=False)

    delete_item(video_obj)
    return jsonify(success=True)


@login_required
@api.route('/course/video/tag-watched', methods=['post'])
def video_tag_watched():
    """

    :return:
    """
    video_id = get_form_value('video_id')
    week_id = get_form_value('week_id')
    course_id = get_form_value('course_id')

    course_obj = Course.query.filter(Course.id == course_id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course did not exist')
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    if week_obj is None:
        return jsonify(success=False, msg='week did not exist')
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    if video_obj is None:
        return jsonify(success=False, msg='video did not exist')

    join_course_record = JoinCourse.query.filter(JoinCourse.course_id == course_obj.id).filter(JoinCourse.student_id == current_user.id).first()
    if join_course_record is None:
        return jsonify(success=False, msg='you have not join the course yet')

    learn_record = LearnRecord.query.filter(
        (LearnRecord.join_course_id == join_course_record.id) &
        (LearnRecord.student_id == current_user.id) &
        (LearnRecord.video_id == video_obj.id)).first()

    if learn_record is None:
        learn_record = LearnRecord()
        learn_record.join_course_id = join_course_record.id
        learn_record.student_id = current_user.id
        learn_record.video_id = video_obj.id

    learn_record.video_watched = True
    db.session.add(learn_record)
    db.session.commit()

    return jsonify(success=True)


@login_required
@api.route('/course/delete', methods=['delete'])
def course_delete():
    """

    :return:
    """

    course_id = get_form_value('course_id')

    course_obj = Course.query.filter(Course.id == course_id).filter(Course.teacher_id == current_user.id).first()
    if course_obj is None:
        return jsonify(success=False)

    delete_item(course_obj)
    return jsonify(success=True)


@login_required
@api.route('/course/submit-assignment-answer', methods=['post'])
def submit_assignment_answer():
    """

    :return:
    """
    video_id = get_form_value('video_id')
    week_id = get_form_value('week_id')
    course_id = get_form_value('course_id')

    print(video_id, course_id, week_id)

    course_obj = Course.query.filter(Course.id == course_id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course did not exist')
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    if week_obj is None:
        return jsonify(success=False, msg='week did not exist')
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    if video_obj is None:
        return jsonify(success=False, msg='video did not exist')

    join_course_record = JoinCourse.query.filter(JoinCourse.course_id == course_obj.id).filter(
        JoinCourse.student_id == current_user.id).first()
    if join_course_record is None:
        return jsonify(success=False, msg='you have not join the course yet')

    learn_record: LearnRecord = LearnRecord.query.filter(
        (LearnRecord.join_course_id == join_course_record.id) & (LearnRecord.student_id == current_user.id) & (
                    LearnRecord.video_id == video_obj.id)).first()
    if learn_record is None or learn_record.video_watched is False:
        return jsonify(success=False, msg='please watch the video and try again later')
    if learn_record.homework_done:
        return jsonify(success=False, msg='You have already done your home work')

    user_answers = get_form_value('user_answers')
    if user_answers is None:
        return jsonify(success=False, msg='please submit your answers')
    try:
        user_answers = json.loads(user_answers)
    except json.JSONDecodeError:
        return jsonify(success=False, msg='please submit your answers'), 400

    if not isinstance(user_answers, list):
        return jsonify(success=False, msg='wrong data format'), 400

    all_questions = []
    for qid, in db.session.query(Question.id).filter(Question.video_id == video_obj.id).all():
        all_questions.append(str(qid))
    for row in user_answers:
        if row['question_id'] not in all_questions:
            return jsonify(success=False, msg='invalid operation'), 400

    do_assignment_record = DoAssignment.query.filter(
        (DoAssignment.course_id == course_obj.id) &
        (DoAssignment.week_id == week_obj.id) &
        (DoAssignment.video_id == video_obj.id) &
        (DoAssignment.student_id == current_user.id) &
        (DoAssignment.is_homework == True)
        ).first()
    if do_assignment_record is None:
        do_assignment_record = DoAssignment()
        do_assignment_record.student_id = current_user.id
        do_assignment_record.course_id = course_obj.id
        do_assignment_record.week_id = week_obj.id
        do_assignment_record.video_id = video_obj.id
        do_assignment_record.is_homework = True
    else:
        Answer.query.filter(Answer.do_assignment_id == do_assignment_record.id).delete()
        db.session.commit()

    db.session.add(do_assignment_record)
    db.session.commit()

    total_score = 0
    student_score = 0
    for row in user_answers:
        question_id = row['question_id']
        answer = row['answer']
        score = 0
        question_obj: Question = Question.query.filter(Question.id == question_id).first()

        if question_obj.kind == 1:
            if answer == question_obj.answer:
                score = question_obj.score

        elif question_obj.kind == 2:
            option_obj: QuestionOption = QuestionOption.query.filter(QuestionOption.question_id == question_obj.id).filter(QuestionOption.id == answer).first()
            if option_obj:
                if option_obj.is_correct:
                    score = question_obj.score

        elif question_obj.kind == 3:
            if answer == question_obj.answer:
                score = question_obj.score

        user_answer_obj = Answer()
        user_answer_obj.do_assignment_id = do_assignment_record.id
        user_answer_obj.question_id = question_obj.id
        user_answer_obj.answer = answer
        user_answer_obj.score = score
        user_answer_obj.is_submitted = True
        user_answer_obj.submitted_at = get_utc_now()
        db.session.add(user_answer_obj)
        db.session.commit()

        total_score += question_obj.score
        student_score += score

    do_assignment_record.total_score = total_score
    do_assignment_record.student_score = student_score
    do_assignment_record.is_submitted = True
    do_assignment_record.finished_at = get_utc_now()
    db.session.add(do_assignment_record)
    db.session.commit()

    learn_record.homework_done = True
    db.session.add(learn_record)
    db.session.commit()

    return jsonify(success=True)


@login_required
@api.route('/course/submit-exercise-answer', methods=['post'])
def submit_exercise_answer():
    """

    :return:
    """
    course_id = get_form_value('course_id')

    course_obj = Course.query.filter(Course.id == course_id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course did not exist')

    join_course_record = JoinCourse.query.filter(JoinCourse.course_id == course_obj.id).filter(
        JoinCourse.student_id == current_user.id).first()
    if join_course_record is None:
        return jsonify(success=False, msg='you have not join the course yet')

    question_id = get_form_value('question_id')
    do_assignment_id = get_form_value('do_assignment_id')
    answer_obj_id = get_form_value('answer_obj_id')
    user_answer = get_form_value('user_answer')

    do_assignment_record = DoAssignment.query.filter(
        DoAssignment.id == do_assignment_id).filter(
        DoAssignment.student_id == current_user.id).filter(
        DoAssignment.course_id == course_obj.id).filter(
        DoAssignment.is_homework == False).first()

    if do_assignment_record is None:
        return jsonify(success=False)

    question_obj: Question = Question.query.filter(
        Question.course_id == course_obj.id).filter(
        Question.id == question_id).filter(Question.is_bank == True).first()
    if question_obj is None:
        return jsonify(success=False)

    answer_obj: Answer = Answer.query.filter(Answer.question_id == question_obj.id).filter(Answer.id == answer_obj_id).first()
    if answer_obj is None or answer_obj.is_submitted:
        return jsonify(success=False)
    score = 0
    if question_obj.kind == 1:
        if user_answer not in 'TF':
            return jsonify(success=False, msg='')
        if user_answer == question_obj.answer:
            score = question_obj.score
    elif question_obj.kind == 2:
        op: QuestionOption = QuestionOption.query.filter(
            QuestionOption.id == user_answer).filter(
            QuestionOption.question_id == question_obj.id).first()
        if op is None:
            return jsonify(success=False, msg='')
        if op.is_correct:
            score = question_obj.score
    else:
        if user_answer == question_obj.answer:
            score = question_obj.score

    answer_obj.score = score
    answer_obj.answer = user_answer
    answer_obj.is_submitted = True
    answer_obj.submitted_at = get_utc_now()
    db.session.add(answer_obj)
    db.session.commit()
    return jsonify(success=True)


@login_required
@api.route('/course/video/log-watch-record', methods=['post'])
def log_watch_record():
    """

    :return:
    """
    video_id = get_form_value('video_id')
    week_id = get_form_value('week_id')
    course_id = get_form_value('course_id')
    duration = get_form_value('duration')
    print(video_id, week_id, course_id, duration)
    course_obj = Course.query.filter(Course.id == course_id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course did not exist')
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    if week_obj is None:
        return jsonify(success=False, msg='week did not exist')
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    if video_obj is None:
        return jsonify(success=False, msg='video did not exist')

    join_course_record = JoinCourse.query.filter(JoinCourse.course_id == course_obj.id).filter(JoinCourse.student_id == current_user.id).first()
    if join_course_record is None:
        return jsonify(success=False, msg='you have not join the course yet')

    try:
        duration = float(duration)
    except (TypeError, ValueError):
        return jsonify(success=False, msg='duration is required and in float type')
    if duration < 60:
        return jsonify(success=False, msg='duration too short. longer than 60 seconds')

    obj = LearnDuration()
    obj.student_id = current_user.id
    obj.duration = duration
    obj.course_id = course_obj.id
    obj.week_id = week_obj.id
    obj.video_id = video_obj.id

    db.session.add(obj)
    db.session.commit()

    return jsonify(success=True)


@login_required
@api.route('/course/video/log-watch-missed', methods=['post'])
def log_watch_missed():
    """

    :return:
    """
    video_id = get_form_value('video_id')
    week_id = get_form_value('week_id')
    course_id = get_form_value('course_id')

    course_obj = Course.query.filter(Course.id == course_id).first()
    if course_obj is None:
        return jsonify(success=False, msg='course did not exist')
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    if week_obj is None:
        return jsonify(success=False, msg='week did not exist')
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    if video_obj is None:
        return jsonify(success=False, msg='video did not exist')

    join_course_record = JoinCourse.query.filter(JoinCourse.course_id == course_obj.id).filter(JoinCourse.student_id == current_user.id).first()
    if join_course_record is None:
        return jsonify(success=False, msg='you have not join the course yet')

    obj = MissedCheckIn()
    obj.student_id = current_user.id
    obj.course_id = course_obj.id
    obj.week_id = week_obj.id
    obj.video_id = video_obj.id

    db.session.add(obj)
    db.session.commit()

    return jsonify(success=True)


@login_required
@api.route('/study-static')
def study_static():
    """

    :return:
    """

    end = get_utc_now().replace(hour=0, minute=0, second=0).replace(tzinfo=None)
    start = end - timedelta(days=30)

    days = []
    _t = start
    while _t <= end:
        days.append(_t)
        _t += timedelta(days=1)

    learn_records = []
    for r in LearnDuration.query.filter(
            LearnDuration.student_id == current_user.id).order_by(
            LearnDuration.created_at.asc()).filter(
            LearnDuration.created_at >= start).filter(
            LearnDuration.created_at < end).all():
        learn_records.append((r.created_at, r.duration))

    dates = []
    learn_durations = []
    for i in range(len(days) - 1):
        d1 = days[i]
        d2 = days[i+1]
        s = 0
        for _time, _duration in learn_records:
            if _time < d1:
                continue
            elif _time >= d2:
                break
            else:
                s += _duration
        dates.append(d1.strftime('%Y-%m-%d'))
        learn_durations.append(round(s / 60, 1))  # hours

    exercises = []
    for do_obj in DoAssignment.query.filter(
        (DoAssignment.student_id == current_user.id) &
        (DoAssignment.created_at >= start.replace(tzinfo=None)) &
        (DoAssignment.created_at < end.replace(tzinfo=None)) &
        (DoAssignment.is_submitted == True)
        ).order_by(DoAssignment.created_at.asc()).all():
        exercises.append((do_obj.created_at, do_obj.student_score, do_obj.total_score))

    scores = []
    percentages = []
    for i in range(len(days) -1):
        d1 = days[i]
        d2 = days[i+1]
        s1 = 0
        s2 = 0
        for _time, student_score, total_score in exercises:
            if _time < d1:
                continue
            elif _time >= d2:
                break
            else:
                s1 += student_score
                s2 += total_score
        scores.append(s1)
        if s2 > 0:
            percentages.append(round(s1 / s2 * 100, 1))
        else:
            percentages.append(None)

    _missed_data = []
    for mid, t in db.session.query(MissedCheckIn.id, MissedCheckIn.created_at).filter(
            (MissedCheckIn.student_id == current_user.id) &
            (MissedCheckIn.created_at >= start.replace(tzinfo=None)) &
            (MissedCheckIn.created_at < end.replace(tzinfo=None))
            ).all():
        _missed_data.append((mid, t))

    missed_data = []
    for i in range(len(days) -1):
        d1 = days[i]
        d2 = days[i+1]
        s1 = 0

        for _time, student_score, total_score in exercises:
            if _time < d1:
                continue
            elif _time >= d2:
                break
            else:
                s1 += 1
        missed_data.append(s1)

    all_video = {}
    for video_id, skill_id in db.session.query(
            Video.id, VideoSkill.skill_id).join(VideoSkill, VideoSkill.video_id == Video.id).join(Week, Week.id == Video.week_id).join(
            JoinCourse, JoinCourse.course_id == Week.course_id).filter(
            JoinCourse.student_id == current_user.id).all():
        if video_id not in all_video:
            all_video[video_id] = [skill_id]
        else:
            all_video[video_id].append(skill_id)

    wrong_questions = []
    for qid, in db.session.query(Answer.question_id).join(DoAssignment, DoAssignment.id == Answer.do_assignment_id).filter(
        (DoAssignment.student_id == current_user.id) & (Answer.is_submitted == True) & (Answer.score == 0)
        ).order_by(Answer.updated_at.desc()).limit(50).all():
        wrong_questions.append(qid)

    weak_skill_id_ls = []
    for skid, in db.session.query(Skill.id).join(QuestionSkill, QuestionSkill.skill_id == Skill.id).filter(
            QuestionSkill.question_id.in_(wrong_questions)).all():
        if skid not in weak_skill_id_ls:
            weak_skill_id_ls.append(skid)

    video_id_to_watch = {}
    if weak_skill_id_ls:
        for vid, in db.session.query(Video.id).join(VideoSkill, VideoSkill.video_id == Video.id).filter(
                VideoSkill.skill_id.in_(weak_skill_id_ls)).all():
            if vid not in video_id_to_watch:
                video_id_to_watch[vid] = 1
            else:
                video_id_to_watch[vid] +=1

    if len(video_id_to_watch) > 3:
        pass
    else:
        for i, _ in all_video.items():
            if i in video_id_to_watch:
                continue
            else:
                video_id_to_watch[i] = len(_)
            if len(video_id_to_watch) >= 3:
                break
    ls = [(i, j) for i,j in video_id_to_watch.items()]
    ls.sort(key=lambda x: x[1])
    ls = ls[:3]
    ls = [i for i, j in ls]
    video_ls = []
    for video_obj in Video.query.filter(Video.id.in_(ls)).all():
        video_ls.append({
            'url': url_for('video_info', video_id=video_obj.id, week_id=video_obj.week_id, course_id=video_obj.week.course_id),
            'poster': video_obj.cover_url,
            'title': video_obj.name
            })

    return jsonify(
        success=True,
        dates=dates,
        learn_durations=learn_durations,
        scores=scores,
        percentages=percentages,
        video_ls=video_ls,
        missed_data=missed_data
        )



