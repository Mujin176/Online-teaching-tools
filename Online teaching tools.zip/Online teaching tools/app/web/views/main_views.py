# coding: utf-8
from .. import app
from flask import render_template
from flask import flash
from flask import abort, request, url_for
from flask import send_file
from flask_login import login_required, current_user
import os
from config import media_dir, default_upload_dir
from datetime import datetime, timedelta, timezone
import dateutil
from flask_ckeditor import upload_fail, upload_success
from werkzeug.utils import secure_filename
from ..utils.common import save_file


@app.route('/')
def index():
    return render_template('index.html', title='good')


@app.route('/media/<path:file_path>', methods=['GET'])
def media(file_path):
    abs_path = os.path.abspath(os.path.join(media_dir, file_path))
    if not os.path.exists(abs_path):
        abort(404)
    return send_file(abs_path)


allowed_extensions = app.config['CKEDITOR_ALLOWED_EXTENSIONS']
allowed_extensions = [i.lower() for i in allowed_extensions]


@app.route('/upload', methods=['POST'])
@login_required
def ck_upload():
    """
    CkEditor upload file
    """
    f = request.files.get('upload')
    extension = os.path.splitext(f.filename)[1][1:]
    print(extension)
    if extension not in allowed_extensions:
        return upload_fail(message=f'Not in supported file formats, eg. {"/".join(allowed_extensions)}。')
    day = datetime.now().strftime('%Y-%m-%d')
    dir_path = default_upload_dir / secure_filename(current_user.username) / day
    abs_fp = save_file(file_obj=f, dir_path=dir_path)
    file_name_with_relative_path = str(abs_fp.relative_to(media_dir)).replace('\\', '/').replace('//', '')
    url = url_for('media', file_path=file_name_with_relative_path)
    return upload_success(url=url)  # return upload_success call


@app.template_filter('default_if_none')
def _default_if_none(s, default: str = None):
    if default is None:
        default = '---'
    if s is None or s == '':
        return default
    else:
        return s


@app.template_filter('format_time')
def _format_time(dt, fmt=None):
    if fmt is None:
        fmt = '%Y-%m-%d %H:%M:%S'
    if isinstance(dt, datetime):
        return dt.strftime(fmt)
    elif isinstance(dt, str):
        date = dateutil.parser.parse(dt)
        native = date.replace(tzinfo=None)
        return native.strftime(fmt)
    else:
        print('format_time error', dt, fmt)
        return ''


@app.template_filter('to_timestamp')
def to_timestamp(dt):
    if not isinstance(dt, datetime):
        return
    if dt.tzinfo is None:
        return int(dt.replace(tzinfo=timezone.utc).timestamp() * 1000)
    else:
        return int(dt.timestamp()*1000)


@app.template_filter('de_package')
def de_package(comment):
    return sorted(list(comment.comments), key=lambda x: x.created_at, reverse=True)


@app.template_filter('find_correct_option_label')
def find_correct_option_label(options):
    base = ord('A')
    for index, op in enumerate(options):
        if op.is_correct:
            return chr(base + index)


@app.template_filter('find_user_option_label')
def find_correct_option_label(options, option_id):
    base = ord('A')
    for index, op in enumerate(options):
        if str(op.id) == str(option_id):
            return chr(base + index)
