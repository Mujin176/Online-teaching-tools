# coding: utf-8
import os

from .. import app, db, csrf
from ..models.lecture_models import (
    Course, Question, QuestionOption, Skill, WeekSkill, Week, JoinCourse, DoAssignment,
    Answer, Comment, Attach, Video, VideoSkill, QuestionSkill, LearnRecord)
from ..models.user_models import User
from flask_login import current_user, login_required
from flask import (request, render_template, jsonify, flash, g, redirect, url_for, abort)
from ..forms.lecture_forms import (CourseCreateForm, TopicCreateForm, CourseUpdateForm, ResourceUploadForm)
from config import media_dir
from datetime import datetime
from ..utils.common import save_file, paginate_helper, get_utc_now


@app.route('/lecture/course-create', methods=['get'])
@login_required
def course_create():
    return render_template('lecture/course_create.html', title='Course Create')


@app.route('/lecture/course-info/<int:course_id>', methods=['get'])
@login_required
def course_info(course_id):
    course_obj = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    skill_ls = Skill.query.filter(Skill.course_id == course_id).order_by(Skill.created_at.asc()).all()
    week_ls = Week.query.filter(Week.course_id == course_id).order_by(Week.created_at.asc()).all()
    attach_ls = Attach.query.filter(Attach.course_id == course_id).filter(Attach.week_id == None).filter(
        Attach.video_id == None).order_by(Attach.created_at.asc()).all()
    return render_template('lecture/course_info.html', title=course_obj.name, course_obj=course_obj, skill_ls=skill_ls,
        week_ls=week_ls, attach_ls=attach_ls)


@app.route('/lecture/course-info/if-joined', methods=['post'])
@login_required
@csrf.exempt
def course_if_joined():
    course_id = request.form.get('course_id')
    course_obj = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    if JoinCourse.query.filter(JoinCourse.course_id == course_id).filter(
            JoinCourse.student_id == current_user.id).count():
        t = True
    else:
        t = False
    return jsonify(success=True, joined=t)


@app.route('/lecture/course-info/join', methods=['post'])
@login_required
@csrf.exempt
def course_user_join():
    course_id = request.form.get('course_id')
    action = request.form.get('action')

    course_obj = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj

    join_obj = JoinCourse.query.filter(JoinCourse.course_id == course_id).filter(
        JoinCourse.student_id == current_user.id).first()
    if action == 'join':
        if join_obj:
            t = True
        else:
            join_obj = JoinCourse()
            join_obj.course_id = course_id
            join_obj.student_id = current_user.id
            db.session.add(join_obj)
            db.session.commit()
            t = True
    elif action == 'quit':
        if join_obj:
            t = False
            db.session.delete(join_obj)
            db.session.commit()
        else:
            t = False
    else:
        abort(404)
        t = False
    return jsonify(success=True, joined=t)


@app.route('/lecture/course-info/update/<int:course_id>', methods=['get'])
@login_required
def course_info_update(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()

    skill_ls = Skill.query.filter(Skill.course_id == course_id).order_by(Skill.created_at.asc()).all()
    week_ls = Week.query.filter(Week.course_id == course_id).order_by(Week.created_at.asc()).all()
    attach_ls = Attach.query.filter(Attach.course_id == course_id).filter(Attach.week_id == None).filter(
        Attach.video_id == None).order_by(Attach.created_at.asc()).all()

    return render_template('lecture/course_update.html', title='Edit Course', course_obj=course_obj, skill_ls=skill_ls,
        week_ls=week_ls, attach_ls=attach_ls)


@app.route('/lecture/course-info/delete/<int:course_id>', methods=['get', 'post'])
@login_required
def course_info_delete(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    if course_obj is None:
        flash(message='Failed to Delete', category='warning')
        return redirect('/')
    db.session.delete(course_obj)
    db.session.commit()
    flash('Deleted', category='success')
    return redirect(url_for('course_my'))


@app.route('/lecture/week-create/<int:course_id>')
def week_create(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    return render_template('lecture/week_create.html', title='Week create', course_obj=course_obj)


@app.route('/lecture/week-info/<int:course_id>-wk-<int:week_id>')
def week_info(course_id, week_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    skill_ls = Skill.query.join(WeekSkill, WeekSkill.skill_id == Skill.id).filter(
        WeekSkill.week_id == week_obj.id).all()
    attach_ls = Attach.query.filter(Attach.week_id == week_obj.id).filter(Attach.course_id == None).filter(
        Attach.video_id == None).all()
    video_ls = Video.query.filter(Video.week_id == week_obj.id).all()
    return render_template('lecture/week_info.html', course_obj=course_obj, week_obj=week_obj, skill_ls=skill_ls,
                           attach_ls=attach_ls, video_ls=video_ls, title=f'{course_obj.name} - week {week_obj.no}')


@app.route('/lecture/week-update/<int:course_id>-wk-<int:week_id>')
@login_required
def week_update(course_id, week_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    skill_ls = Skill.query.join(WeekSkill, WeekSkill.skill_id == Skill.id).filter(
        WeekSkill.week_id == week_obj.id).all()
    attach_ls = Attach.query.filter(Attach.week_id == week_obj.id).filter(Attach.course_id == None).filter(
        Attach.video_id == None).all()
    return render_template('lecture/week_update.html', course_obj=course_obj, week_obj=week_obj, skill_ls=skill_ls,
                           attach_ls=attach_ls)


@app.route('/course/list')
@login_required
def course_list():
    """

    :return:
    """
    q = request.args.get('q', '').strip('%')
    page, per_page = paginate_helper()
    course_query = Course.query.order_by(Course.created_at.desc())
    if q:
        course_query = course_query.filter(Course.name.like(f'%{q}%'))
    course_ls = course_query.paginate(page=page, per_page=per_page, error_out=False)
    return render_template('lecture/course_list.html', title='All Courses', course_ls=course_ls)


@app.route('/course/my')
@login_required
def course_my():
    """

    :return:
    """
    q = request.args.get('q', '').strip('%')
    page, per_page = paginate_helper()
    course_query = Course.query.order_by(Course.created_at.desc())
    if current_user.role == 2:
        course_query = course_query.filter(Course.teacher_id == current_user.id)
    else:
        course_query = course_query.join(JoinCourse, JoinCourse.course_id == Course.id).filter(
            JoinCourse.student_id == current_user.id)
    if q:
        course_query = course_query.filter(Course.name.like(f'%{q}%'))
    course_ls = course_query.paginate(page=page, per_page=per_page, error_out=False)

    return render_template('lecture/course_list.html', title='My Courses', course_ls=course_ls)


@app.route('/lecture/video-create/<int:course_id>-wk-<int:week_id>')
@login_required
def video_create(course_id, week_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    return render_template('lecture/video_create.html', title='Video create', course_obj=course_obj, week_obj=week_obj)


@app.route('/lecture/video-info/<int:course_id>-wk-<int:week_id>-vid-<int:video_id>')
@login_required
def video_info(course_id, week_id, video_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    skill_ls = Skill.query.join(VideoSkill, VideoSkill.skill_id == Skill.id).filter(
        VideoSkill.video_id == video_obj.id).all()
    attach_ls = Attach.query.filter(Attach.video_id == video_obj.id).filter(Attach.course_id == None).filter(
        Attach.week_id == None).all()

    joined = JoinCourse.query.filter(
        JoinCourse.student_id == current_user.id).filter(
        JoinCourse.course_id == course_obj.id).first() is not None

    video_watched = False
    homework_done = False
    if joined:
        learning_record: LearnRecord = LearnRecord.query.filter(
            (LearnRecord.student_id == current_user.id) & (LearnRecord.video_id == video_obj.id)
            ).first()
        if learning_record:
            video_watched = learning_record.video_watched
            homework_done = learning_record.homework_done

    return render_template(
        'lecture/video_info.html', course_obj=course_obj, week_obj=week_obj, skill_ls=skill_ls,
        attach_ls=attach_ls, video_obj=video_obj, title=video_obj.name, joined=joined,
        video_watched=video_watched, homework_done=homework_done)


@app.route('/lecture/video-update/<int:course_id>-wk-<int:week_id>-vid-<int:video_id>')
@login_required
def video_update(course_id, week_id, video_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    skill_ls = Skill.query.join(VideoSkill, VideoSkill.skill_id == Skill.id).filter(
        VideoSkill.video_id == video_obj.id).all()
    attach_ls = Attach.query.filter(Attach.video_id == video_obj.id).filter(Attach.course_id == None).filter(
        Attach.week_id == None).all()
    return render_template('lecture/video_update.html', course_obj=course_obj, week_obj=week_obj, skill_ls=skill_ls,
                           attach_ls=attach_ls, video_obj=video_obj, title='Edit Video')


@app.route('/lecture/do-assignment/<int:course_id>-wk-<int:week_id>-vid-<int:video_id>')
@login_required
def do_assignment(course_id, week_id, video_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()

    join_course_record = JoinCourse.query.filter(
        JoinCourse.student_id == current_user.id).filter(
        JoinCourse.course_id == course_obj.id).first()

    joined = join_course_record is not None

    if not joined:
        flash('Please join this course and try again later', category='warning')
        return redirect(url_for('course_info', course_id=course_obj.id))

    video_watched = False
    homework_done = False
    if joined:
        learning_record: LearnRecord = LearnRecord.query.filter(
            (LearnRecord.student_id == current_user.id) & (LearnRecord.video_id == video_obj.id)).first()
        if learning_record:
            video_watched = learning_record.video_watched
            homework_done = learning_record.homework_done
    if not video_watched:
        flash('Please finish watching this video, and do assignment later', category='warning')
        return redirect(url_for('video_info', course_id=course_obj.id, week_id=week_obj.id, video_id=video_obj.id))

    if homework_done:
        do_assignment_record = DoAssignment.query.filter(
            (DoAssignment.course_id == course_obj.id) &
            (DoAssignment.week_id == week_obj.id) &
            (DoAssignment.video_id == video_obj.id) &
            (DoAssignment.student_id == current_user.id) &
            (DoAssignment.is_homework == True)).first()
        user_answers = {}
        for an in Answer.query.filter(Answer.do_assignment_id == do_assignment_record.id).all():
            user_answers[an.question_id] = {
                'answer': an.answer,
                'score': an.score
                }
    else:
        user_answers = {}

    judge_questions = Question.query.filter(Question.video_id == video_obj.id).filter(Question.kind == 1).all()
    choices_questions = Question.query.filter(Question.video_id == video_obj.id).filter(Question.kind == 2).all()
    fill_questions = Question.query.filter(Question.video_id == video_obj.id).filter(Question.kind == 3).all()

    return render_template(
        'lecture/student_do_homework.html', course_obj=course_obj, week_obj=week_obj, video_obj=video_obj,
        judge_questions=judge_questions, choices_questions=choices_questions, fill_questions=fill_questions,
        title='Do Assignment' if not homework_done else 'Assignment Record',
        homework_done=homework_done, video_watched=video_watched, joined=joined,
        user_answers=user_answers
        )


@app.route('/lecture/video-question/<int:course_id>-wk-<int:week_id>-vid-<int:video_id>/create')
@login_required
def video_question_create(course_id, week_id, video_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    skill_ls = Skill.query.join(VideoSkill, VideoSkill.skill_id == Skill.id).filter(
        VideoSkill.video_id == video_obj.id).all()
    attach_ls = Attach.query.filter(Attach.video_id == video_obj.id).filter(Attach.course_id == None).filter(
        Attach.week_id == None).all()
    return render_template('lecture/video_question_create.html', course_obj=course_obj, week_obj=week_obj,
                           skill_ls=skill_ls, attach_ls=attach_ls, video_obj=video_obj, title='Create Question')


@app.route('/lecture/video-question/<int:course_id>-wk-<int:week_id>-vid-<int:video_id>/list')
@login_required
def video_question_list(course_id, week_id, video_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()

    judge_questions = Question.query.filter(Question.video_id == video_obj.id).filter(Question.kind == 1).all()
    choices_questions = Question.query.filter(Question.video_id == video_obj.id).filter(Question.kind == 2).all()
    fill_questions = Question.query.filter(Question.video_id == video_obj.id).filter(Question.kind == 3).all()

    return render_template('lecture/video_question_list.html', course_obj=course_obj, week_obj=week_obj,
                           video_obj=video_obj, title='Home Work', fill_questions=fill_questions,
                           choices_questions=choices_questions, judge_questions=judge_questions)


@app.route('/lecture/video-question/<int:course_id>-wk-<int:week_id>-vid-<int:video_id>/update/<int:question_id>')
@login_required
def video_question_update(course_id, week_id, video_id, question_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    skill_ls = Skill.query.join(VideoSkill, VideoSkill.skill_id == Skill.id).filter(
        VideoSkill.video_id == video_obj.id).all()
    attach_ls = Attach.query.filter(Attach.video_id == video_obj.id).filter(Attach.course_id == None).filter(
        Attach.week_id == None).all()
    question_obj = Question.query.filter(Question.id == question_id).filter(
        Question.week_id == week_obj.id).first_or_404()
    question_skills = [i for i, in db.session.query(QuestionSkill.skill_id).filter(
        QuestionSkill.question_id == question_obj.id).all()]
    question_options = [i.content for i in
                        QuestionOption.query.filter(QuestionOption.question_id == question_obj.id).all()]
    return render_template('lecture/video_question_update.html', course_obj=course_obj, week_obj=week_obj,
                           skill_ls=skill_ls, attach_ls=attach_ls, video_obj=video_obj, question_obj=question_obj,
                           question_skills=question_skills, question_options=question_options, title='Edit Question')


@app.route('/lecture/video-question/<int:course_id>-wk-<int:week_id>-vid-<int:video_id>/delete/<int:question_id>')
@login_required
def video_question_delete(course_id, week_id, video_id, question_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj
    week_obj = Week.query.filter(Week.course_id == course_obj.id).filter(Week.id == week_id).first()
    video_obj = Video.query.filter(Video.id == video_id).filter(Video.week_id == week_obj.id).first()
    question_obj = Question.query.filter(Question.id == question_id).filter(
        Question.week_id == week_obj.id).first_or_404()
    db.session.delete(question_obj)
    db.session.commit()
    flash('deleted', category='success')
    return redirect(url_for('video_question_list', course_id=course_obj.id, week_id=week_obj.id, video_id=video_obj.id))


@app.route('/lecture/video-question/<int:course_id>/create')
@login_required
def course_question_create(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj
    skill_ls = Skill.query.filter(Skill.course_id == course_obj.id).all()
    return render_template('lecture/course_question_create.html', course_obj=course_obj, skill_ls=skill_ls,
                           title='Create Question')


@app.route('/lecture/course-question/<int:course_id>/list')
@login_required
def course_question_list(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj

    judge_questions = Question.query.filter(Question.course_id == course_obj.id).filter(Question.kind == 1).filter(Question.is_bank == True).all()
    choices_questions = Question.query.filter(Question.course_id == course_obj.id).filter(Question.kind == 2).filter(Question.is_bank == True).all()
    fill_questions = Question.query.filter(Question.course_id == course_obj.id).filter(Question.kind == 3).filter(Question.is_bank == True).all()

    return render_template('lecture/course_question_list.html', course_obj=course_obj, title='Question Bank',
                           fill_questions=fill_questions, choices_questions=choices_questions,
                           judge_questions=judge_questions)


@app.route('/lecture/course-question/<int:course_id>/update/<int:question_id>')
@login_required
def course_question_update(course_id, question_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj

    skill_ls = Skill.query.filter(Skill.course_id == course_obj.id).all()

    question_obj = Question.query.filter(Question.id == question_id).filter(
        Question.course_id == course_obj.id).first_or_404()
    question_skills = [i for i, in db.session.query(QuestionSkill.skill_id).filter(
        QuestionSkill.question_id == question_obj.id).all()]
    question_options = [i.content for i in
                        QuestionOption.query.filter(QuestionOption.question_id == question_obj.id).all()]
    return render_template('lecture/course_question_update.html', course_obj=course_obj, skill_ls=skill_ls,
                           question_obj=question_obj, question_skills=question_skills,
                           question_options=question_options, title='Edit Question')


@app.route('/lecture/course-question/<int:course_id>/delete/<int:question_id>')
@login_required
def course_question_delete(course_id, question_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).filter(
        Course.teacher_id == current_user.id).first_or_404()
    g.course_obj = course_obj

    question_obj = Question.query.filter(Question.id == question_id).filter(
        Question.course_id == course_obj.id).first_or_404()
    db.session.delete(question_obj)
    db.session.commit()
    flash('deleted', category='success')
    return redirect(url_for('course_question_list', course_id=course_obj.id,))


@app.route('/lecture/course-exercise/<int:course_id>/create')
@login_required
def course_exercise_create(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    join_course_record = JoinCourse.query.filter(JoinCourse.student_id == current_user.id).filter(
        JoinCourse.course_id == course_obj.id).first()
    if join_course_record is None:
        flash('Please join this course and try again later', category='warning')
        return redirect(url_for('course_info', course_id=course_obj.id))

    do_assignment_record = DoAssignment.query.filter(
        DoAssignment.is_submitted == False).filter(
        DoAssignment.course_id == course_obj.id).filter(
        DoAssignment.is_homework == False).order_by(DoAssignment.created_at.desc()).first()
    if do_assignment_record is None:
        do_assignment_record = DoAssignment()
        do_assignment_record.student_id = current_user.id
        do_assignment_record.course_id = course_obj.id
        do_assignment_record.is_homework = False
        do_assignment_record.total_score = 0
        do_assignment_record.student_score = 0
        do_assignment_record.is_submitted = False
        db.session.add(do_assignment_record)
        db.session.commit()
    return redirect(url_for('course_exercise_do', course_id=course_obj.id, do_id=do_assignment_record.id))


@app.route('/lecture/course-exercise/<int:course_id>/do/<int:do_id>')
@login_required
def course_exercise_do(course_id, do_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    do_assignment_record: DoAssignment = DoAssignment.query.filter(
        DoAssignment.id == do_id).filter(
        DoAssignment.course_id == course_obj.id).filter(
        DoAssignment.student_id == current_user.id).filter(
        DoAssignment.is_homework == False).first_or_404()
    if do_assignment_record.is_submitted:
        answer_obj_list = Answer.query.filter(Answer.do_assignment_id == do_assignment_record.id).order_by(Answer.created_at.asc()).all()
        return render_template(
            'lecture/course_exercise_record.html',
            course_obj=course_obj,
            do_assignment_record=do_assignment_record,
            answer_obj_list=answer_obj_list,
            title='Exercise Record'
            )
    else:
        sq = Answer.query.filter(Answer.do_assignment_id == do_assignment_record.id).count()  # how many questions finished already
        all_questions = Question.query.filter(Question.course_id == course_obj.id).filter(Question.is_bank == True).order_by(Question.score.asc()).all()
        last_answer: Answer = Answer.query.filter(Answer.do_assignment_id == do_assignment_record.id).order_by(Answer.created_at.desc()).first()
        if last_answer is None:
            # the first one
            sq += 1
            question_obj = all_questions[0]
            answer_obj = Answer()
            answer_obj.do_assignment_id = do_assignment_record.id
            answer_obj.question_id = question_obj.id
            db.session.add(answer_obj)
            db.session.commit()
            return render_template('lecture/course_exercise.html', course_obj=course_obj, answer_obj=answer_obj, question_obj=question_obj, sq=sq, do_assignment_record=do_assignment_record, title='DO EXERCISE')
        elif not last_answer.is_submitted:
            # last question did not been answered yet.
            question_obj = last_answer.question
            answer_obj = last_answer
            return render_template('lecture/course_exercise.html', course_obj=course_obj, answer_obj=answer_obj, question_obj=question_obj, sq=sq, do_assignment_record=do_assignment_record, title='DO EXERCISE')
        else:
            # go to next question
            sq += 1
            user_score = 0
            total_score = 0
            t = 0
            done_questions = []
            for answer_obj in Answer.query.filter(Answer.do_assignment_id == do_assignment_record.id).order_by(Answer.created_at.asc()):
                t += 1
                user_score += answer_obj.score
                total_score += answer_obj.question.score
                done_questions.append(answer_obj.question_id)
            avg = round(user_score / total_score * 10, 0)
            question_obj: Question = None
            for q in all_questions:

                if q.id in done_questions:
                    continue
                else:
                    if t > 3:
                        if q.score < avg + 1:
                            question_obj = q
                            break
                        else:
                            break
                    else:
                        question_obj = q
                        break
            if question_obj is None:
                flash('You have done all exercises for your level', category='info')
                do_assignment_record.is_submitted = True
                do_assignment_record.total_score = total_score
                do_assignment_record.student_score = user_score
                do_assignment_record.finished_at = get_utc_now()
                db.session.add(do_assignment_record)
                db.session.commit()
                return redirect(url_for('course_info', course_id=course_obj.id))
            else:
                answer_obj = Answer()
                answer_obj.do_assignment_id = do_assignment_record.id
                answer_obj.question_id = question_obj.id
                db.session.add(answer_obj)
                db.session.commit()

                return render_template('lecture/course_exercise.html', course_obj=course_obj, answer_obj=answer_obj, question_obj=question_obj, sq=sq, do_assignment_record=do_assignment_record, title='DO EXERCISE')


@app.route('/lecture/course-exercise/<int:course_id>/histories')
@login_required
def course_exercise_histories(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    join_course_record = JoinCourse.query.filter(JoinCourse.student_id == current_user.id).filter(
        JoinCourse.course_id == course_obj.id).first()
    if join_course_record is None:
        flash('Please join this course and try again later', category='warning')
        return redirect(url_for('course_info', course_id=course_obj.id))
    ls = DoAssignment.query.filter(
        DoAssignment.course_id == course_obj.id).filter(
        DoAssignment.is_submitted == True).filter(
        DoAssignment.student_id == current_user.id).filter(
        DoAssignment.is_homework == False).order_by(DoAssignment.created_at.desc()).all()
    return render_template('lecture/course_exercise_histories.html', course_obj=course_obj, ls=ls, title='Exercise Histories')


@app.route('/lecture/course-exercise/<int:course_id>/wrongs')
@login_required
def course_exercise_wrongs(course_id):
    course_obj: Course = Course.query.filter(Course.id == course_id).first_or_404()
    g.course_obj = course_obj
    join_course_record = JoinCourse.query.filter(JoinCourse.student_id == current_user.id).filter(
        JoinCourse.course_id == course_obj.id).first()
    if join_course_record is None:
        flash('Please join this course and try again later', category='warning')
        return redirect(url_for('course_info', course_id=course_obj.id))

    answer_obj_list = Answer.query.join(DoAssignment, DoAssignment.id == Answer.do_assignment_id).filter(
        DoAssignment.course_id == course_obj.id).filter(
        DoAssignment.student_id == current_user.id).filter(
        DoAssignment.is_homework == False).filter(
        Answer.is_submitted == True).order_by(DoAssignment.created_at.desc()).all()
    return render_template('lecture/course_exercise_record.html',  course_obj=course_obj,
            answer_obj_list=answer_obj_list, title='Wrong Records')


@app.route('/lecture/study-report')
@login_required
def study_report():
    """

    :return:
    """

    return render_template('lecture/study_report.html', title='Study Report')
