window.ajaxRequest = function ( url, method, formData ){
    return new Promise(( resolve, reject ) => {
        $.ajax({
            url: url,
            type: method,
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success( res ){
                resolve(res)
            },
            error( err, xhr, msg ){
                reject(err, xhr, msg)
            }
        })
    })
}

